# fire detect with lighter > 2024-01-11 1:08am
https://universe.roboflow.com/newdetectfire/fire-detect-with-lighter

Provided by a Roboflow user
License: CC BY 4.0

